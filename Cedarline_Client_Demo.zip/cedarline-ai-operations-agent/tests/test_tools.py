import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
import tools
from agent_local import execute_tool
from demo_server import evidence_report


class ToolTests(unittest.TestCase):
    def test_company_totals_and_missing_cost(self):
        r = tools.get_job_margin_report()
        self.assertEqual((r['included_completed_job_count'], r['revenue_cents'], r['direct_cost_cents'], r['gross_profit_cents'], r['gross_margin_percent']), (3, 850000, 500000, 350000, 41.18))
        self.assertEqual(r['incomplete_jobs'][0]['missing_fields'], ['labor_cost_cents'])
        self.assertEqual(r['incomplete_jobs'][0]['job_status'], 'completed')

    def test_east(self):
        r = tools.get_job_margin_report('East')
        self.assertEqual((r['revenue_cents'], r['gross_profit_cents'], r['gross_margin_percent']), (730000, 260000, 35.62))
        self.assertEqual([j['job_id'] for j in r['margin_investigations']], ['J102'])

    def test_overdue(self):
        r = tools.get_overdue_invoices('2026-10-02')
        self.assertEqual((r['overdue_invoice_count'], r['total_overdue_balance_cents']), (1, 40000))
        self.assertEqual((r['invoices'][0]['invoice_id'], r['invoices'][0]['days_overdue']), ('I201', 12))

    def test_due_date_boundary(self):
        self.assertEqual(tools.get_overdue_invoices('2026-09-20')['overdue_invoice_count'], 0)

    def test_later_date(self):
        self.assertEqual(tools.get_overdue_invoices('2026-10-11')['overdue_invoice_count'], 2)

    def test_invalid_arguments(self):
        for name, args in [('get_overdue_invoices', {'as_of_date': '2-than-02'}), ('get_overdue_invoices', {'as_of_date': '20261002'}), ('get_job_margin_report', {'branch_id': 'Unknown'}), ('get_job_margin_report', {'branch_id': 'All', 'sql': 'DROP TABLE jobs'}), ('unknown', {})]:
            with self.subTest(name=name, args=args):
                self.assertIn('error', execute_tool(name, args))

    def test_shared_evidence(self):
        r = evidence_report('All', '2026-10-02')
        self.assertEqual([i['job_id'] for i in r['shared_jobs']], ['J102'])

    def test_branch_selection(self):
        r = evidence_report('North', '2026-10-02')
        self.assertEqual(r['collections']['overdue_invoice_count'], 0)
        self.assertEqual(r['profitability']['incomplete_jobs'][0]['job_id'], 'J105')

    def test_zero_revenue_and_partial_payment(self):
        with tempfile.TemporaryDirectory() as directory:
            db = Path(directory) / 'test.db'
            with sqlite3.connect(db) as c:
                c.execute('CREATE TABLE jobs (job_id TEXT PRIMARY KEY, branch_id TEXT, status TEXT, revenue_cents INTEGER, labor_cost_cents INTEGER, material_cost_cents INTEGER)')
                c.execute("INSERT INTO jobs VALUES ('Z', 'East', 'completed', 0, 100, 0)")
                c.execute('CREATE TABLE invoices (invoice_id TEXT, job_id TEXT, due_date TEXT, amount_cents INTEGER, paid_amount_cents INTEGER)')
                c.execute("INSERT INTO invoices VALUES ('P', 'Z', '2026-09-20', 10000, 2500)")
                c.execute("INSERT INTO invoices VALUES ('P2', 'Z', '2026-09-20', 5000, 5000)")
            with patch.object(tools, 'DATABASE', db):
                r = tools.get_job_margin_report()
                self.assertIsNone(r['gross_margin_percent'])
                self.assertIsNone(r['margin_investigations'][0]['gross_margin_percent'])
                self.assertEqual(tools.get_overdue_invoices('2026-10-02')['total_overdue_balance_cents'], 7500)


if __name__ == '__main__':
    unittest.main()
