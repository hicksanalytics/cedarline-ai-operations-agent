# Validation report

Fourteen automated tests passed after rebuilding the uploaded CSVs: company totals and missing cost; East totals; overdue balance; due-date boundary; later-date behavior; invalid arguments; shared evidence; branch evidence selection; zero revenue and partial payments; no-evidence refusal; argument recovery; missing-required-tool refusal; combined-tool success; and tool-call limits.

HTTP checks passed for HTML delivery and evidence showing the J102 and I201 association. Browser execution and visual rendering could not be inspected because no browser executable was available here. The live UI subprocess was not run against a local model in this environment.

User-provided Windows traces earlier demonstrated successful local profitability, collections, and combined tools. They also showed unsupported judgments, missed calls, a malformed date, and a timeout. Those examples informed validation, recovery, and coverage. They are not an accuracy benchmark.

## Local acceptance

1. Run the fourteen tests.
2. Open the browser demo at desktop and narrow widths.
3. Select North: J105 appears and overdue balance is zero.
4. Restore All and run the management AI review with Ollama. Confirm both tools and compare prose to evidence.
5. Stop Ollama and run again: it must fail visibly while evidence remains usable.

Required-tool checks validate names and outcomes, not exact scope or all claims. Model prose may misstate evidence. No policy retrieval, roles, approvals, multi-tenancy, historical margins, or public hosting is included. Small fixtures do not establish behavior on real client datasets.
