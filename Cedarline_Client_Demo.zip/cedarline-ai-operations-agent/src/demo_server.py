"""Local client demonstration. No third-party Python dependencies."""
import json
import os
import subprocess
import sys
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from agent_local import execute_tool
from tools import get_job_margin_report, get_overdue_invoices

ROOT = Path(__file__).resolve().parents[1]
JOBS = {}
LOCK = threading.Lock()
POOL = ThreadPoolExecutor(max_workers=1)
REQUIRED = {
    "profitability": "get_job_margin_report",
    "collections": "get_overdue_invoices",
    "management": "get_job_margin_report,get_overdue_invoices",
}


def review_inputs(mode, branch, as_of):
    if mode not in REQUIRED or branch not in ("All", "North", "East", "South"):
        raise ValueError("Invalid review selection")
    result = execute_tool("get_overdue_invoices", {"as_of_date": as_of})
    if "error" in result:
        raise ValueError(result["error"])
    return result


def evidence_report(branch, as_of):
    overdue = review_inputs("management", branch, as_of)
    margin = get_job_margin_report(None if branch == "All" else branch)
    # The invoice tool is company-wide; filter its evidence explicitly for UI selection.
    if branch != "All":
        overdue["invoices"] = [i for i in overdue["invoices"] if i["branch_id"] == branch]
        overdue["overdue_invoice_count"] = len(overdue["invoices"])
        overdue["total_overdue_balance_cents"] = sum(i["balance_cents"] for i in overdue["invoices"])
    flagged = {j["job_id"] for j in margin["margin_investigations"]}
    links = [i for i in overdue["invoices"] if i["job_id"] in flagged]
    return {"profitability": margin, "collections": overdue, "shared_jobs": links}


def run_live(job_id, mode, branch, as_of):
    env = dict(os.environ)
    env["CEDARLINE_REQUIRED_TOOLS"] = REQUIRED[mode]
    if mode == "profitability":
        question = f"Review profitability for branch {branch}. Include totals, missing financial values and flagged job IDs."
    elif mode == "collections":
        question = f"Review company-wide overdue invoices as of {as_of}. Cite invoice IDs, balances and days overdue."
    else:
        question = f"Use both tools for company-wide profitability and overdue invoices as of {as_of}. Include missing data and link shared job IDs."
    # Keep collections and combined live reviews company-wide: the invoice tool has no branch parameter.
    question += " Answer briefly. Do not infer causes or classify overall margin as healthy."
    try:
        result = subprocess.run([sys.executable, "-u", str(ROOT / "src/agent_local.py")],
                                input=question + "\n", text=True, capture_output=True,
                                env=env, cwd=ROOT, timeout=1800)
        output = result.stdout
        if result.returncode or "Agent stopped:" in output or "No verified answer:" in output:
            status, answer = "failed", "The live run could not complete. Review the trace; verified evidence remains available."
        elif "CEDARLINE ANALYST\n" not in output:
            status, answer = "failed", "No final model answer was returned."
        else:
            status = "complete"
            answer = output.split("CEDARLINE ANALYST\n", 1)[1].split("[Successful tools]", 1)[0].strip()
        trace = output + ("\n" + result.stderr if result.stderr else "")
    except subprocess.TimeoutExpired:
        status, answer, trace = "failed", "Live run timed out.", "The process was stopped after 30 minutes."
    except Exception as error:
        status, answer, trace = "failed", "Live run failed.", str(error)
    with LOCK:
        JOBS[job_id].update(status=status, answer=answer, trace=trace)


class Handler(BaseHTTPRequestHandler):
    def reply(self, status, value, kind="application/json"):
        body = value if isinstance(value, bytes) else json.dumps(value).encode()
        self.send_response(status)
        self.send_header("Content-Type", kind + "; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = urlparse(self.path)
        try:
            if path.path == "/":
                return self.reply(200, (ROOT / "ui/index.html").read_bytes(), "text/html")
            if path.path == "/api/evidence":
                query = parse_qs(path.query)
                return self.reply(200, evidence_report(query.get("branch", ["All"])[0], query.get("date", ["2026-10-02"])[0]))
            if path.path.startswith("/api/jobs/"):
                with LOCK:
                    job = JOBS.get(path.path.rsplit("/", 1)[1])
                    response = dict(job) if job else None
                return self.reply(200 if response else 404, response or {"error": "Unknown run"})
            return self.reply(404, {"error": "Not found"})
        except (ValueError, FileNotFoundError) as error:
            return self.reply(400, {"error": str(error)})

    def do_POST(self):
        # Browser requests must originate from this loopback demo, not another website.
        origin = self.headers.get("Origin", "")
        if origin != "http://127.0.0.1:8765":
            return self.reply(403, {"error": "Open the demo at http://127.0.0.1:8765"})
        if self.path != "/api/run":
            return self.reply(404, {"error": "Not found"})
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 < length <= 4096:
                raise ValueError("Invalid request size")
            payload = json.loads(self.rfile.read(length))
            mode = payload.get("mode", "management")
            branch = payload.get("branch", "All")
            as_of = payload.get("date", "2026-10-02")
            review_inputs(mode, branch, as_of)
            if mode != "profitability" and branch != "All":
                raise ValueError("Live collections and management reviews require All branches")
            with LOCK:
                if any(j["status"] == "running" for j in JOBS.values()):
                    return self.reply(409, {"error": "A live run is already in progress"})
                # Retain a bounded in-memory history, not an ever-growing log.
                if len(JOBS) >= 20:
                    JOBS.pop(next(iter(JOBS)))
                job_id = uuid.uuid4().hex
                JOBS[job_id] = {"status": "running", "answer": "", "trace": ""}
            POOL.submit(run_live, job_id, mode, branch, as_of)
            return self.reply(202, {"job_id": job_id})
        except (ValueError, TypeError, AttributeError) as error:
            return self.reply(400, {"error": str(error)})


if __name__ == "__main__":
    print("Cedarline demo: http://127.0.0.1:8765")
    print("Synthetic data only. Press Ctrl+C to stop.")
    ThreadingHTTPServer(("127.0.0.1", 8765), Handler).serve_forever()
