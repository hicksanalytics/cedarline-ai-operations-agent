"""Control-flow checks use scripted responses, not a live model."""
import contextlib
import io
import os
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'src'))
import agent_local as agent


def call(name, args):
    return {'message': {'role': 'assistant', 'content': '', 'tool_calls': [{'function': {'name': name, 'arguments': args}}]}}


def answer():
    return {'message': {'role': 'assistant', 'content': 'Report complete.'}}


class AgentTests(unittest.TestCase):
    def run_agent(self, responses, required=''):
        output = io.StringIO()
        with patch.dict(os.environ, {'CEDARLINE_REQUIRED_TOOLS': required}), patch('builtins.input', return_value='Review all branches as of 2026-10-02'), patch.object(agent, 'ask_model', side_effect=responses), contextlib.redirect_stdout(output):
            agent.main()
        return output.getvalue()

    def test_no_evidence_stops(self):
        text = self.run_agent([answer(), answer()])
        self.assertIn('No verified answer', text)
        self.assertNotIn('CEDARLINE ANALYST', text)

    def test_date_recovery(self):
        text = self.run_agent([call('get_overdue_invoices', {'as_of_date': 'bad'}), answer(), call('get_overdue_invoices', {'as_of_date': '2026-10-02'}), answer()])
        self.assertIn('required argument correction', text)
        self.assertIn('CEDARLINE ANALYST', text)

    def test_missing_required_tool_stops(self):
        responses = [call('get_job_margin_report', {'branch_id': 'All'}), answer(), answer()]
        with self.assertRaisesRegex(RuntimeError, 'required tools missing'):
            self.run_agent(responses, 'get_job_margin_report,get_overdue_invoices')

    def test_both_tools_pass(self):
        first = call('get_job_margin_report', {'branch_id': 'All'})
        first['message']['tool_calls'] += call('get_overdue_invoices', {'as_of_date': '2026-10-02'})['message']['tool_calls']
        text = self.run_agent([first, answer()], 'get_job_margin_report,get_overdue_invoices')
        self.assertIn('CEDARLINE ANALYST', text)

    def test_tool_limit(self):
        with self.assertRaisesRegex(RuntimeError, 'Tool-call limit'):
            self.run_agent([call('get_job_margin_report', {'branch_id': 'All'})] * 6)


if __name__ == '__main__':
    unittest.main()
