$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
python .\src\build_database.py
if ($LASTEXITCODE -ne 0) { throw "Job load failed" }
python .\src\load_invoices.py
if ($LASTEXITCODE -ne 0) { throw "Invoice load failed" }
Write-Host "Open http://127.0.0.1:8765 in your browser. Ctrl+C stops the server."
python .\src\demo_server.py
