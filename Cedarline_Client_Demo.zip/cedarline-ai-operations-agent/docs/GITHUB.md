# Publish to GitHub

Destination: https://github.com/hicksanalytics/cedarline-ai-operations-agent

The GitHub connector returned Not Found for this private repository and listed no app installations. No remote files were committed during packaging. Keep the repository private while resolving access.

## Connector access

Open GitHub Settings, then Applications. If an installed ChatGPT or OpenAI GitHub integration exists, configure its repository access to include `cedarline-ai-operations-agent`. If no installation exists, reconnect the GitHub plugin in ChatGPT and grant access to the selected repository. Return here after connecting for the commit step.

## Local publishing alternative

Open the delivered folder in VS Code. These commands assume an empty destination and no existing local Git repository. Use your permitted personal GitHub account. Check `git --version`, then run:

```powershell
git init
git branch -M main
git add .gitignore README.md src ui data tests docs briefs knowledge archive start_demo.ps1
git status
```

Review staged files. No secrets, `.venv`, databases, or model downloads should appear. Configure your own Git author name and preferred email if requested.

```powershell
git commit -m "Add Cedarline local AI operations demo"
git remote add origin https://github.com/hicksanalytics/cedarline-ai-operations-agent.git
git push -u origin main
```

GitHub authentication may be required. If the remote already contains commits or a remote already exists, stop and inspect; do not force-push. Private repo links are not accessible to prospects unless they have access.
