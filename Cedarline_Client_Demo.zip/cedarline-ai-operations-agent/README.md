# Cedarline AI Operations Assistant

A Hicks Analytics portfolio demonstration connecting a local language model to SQL tools for job profitability and overdue invoices. All companies, policies, people, and records are fictional. This is a read-only prototype.

## Start on Windows

Open this folder in VS Code. Python 3.10 or newer is required. Active demo code uses only Python's standard library: no Python packages, API keys, or paid API service are needed.

```powershell
python src/build_database.py
python src/load_invoices.py
python -m unittest discover -s tests -p "test_*.py" -v
python src/demo_server.py
```

Open **http://127.0.0.1:8765** in your browser. Leave the terminal running; Ctrl+C stops it. Alternatively use `start_demo.ps1` if PowerShell scripts are permitted. Do not change workplace execution policies to run this project.

The verified evidence interface works without a model. For optional live AI, install Ollama from https://ollama.com/download/windows and run:

```powershell
ollama pull qwen3:4b-instruct
```

Keep Ollama running, then choose a review in the browser. Live profitability supports branch selection; live collections and management reviews are company-wide. Evidence panels support filtering both sources by branch. A filter is not an authorization control.

CPU generation can take minutes. Each model request has a five-minute timeout; the entire live subprocess has a thirty-minute limit. Only one live review runs at a time. The UI shows elapsed time and the completed trace.

## Command line agent

```powershell
python src/agent_local.py
```

Ask: `Which East branch jobs need margin investigation?`

To require both tools in a CLI run:

```powershell
$env:CEDARLINE_REQUIRED_TOOLS = "get_job_margin_report,get_overdue_invoices"
python src/agent_local.py
Remove-Item Env:CEDARLINE_REQUIRED_TOOLS
```

Optional `CEDARLINE_MODEL` selects another downloaded tool-capable model. The API endpoint remains loopback-only.

## Training results

Three completed jobs with known costs produce $8,500 revenue, $5,000 direct costs, $3,500 profit, and 41.18% weighted gross margin. J102 has a 25% margin and needs review. J105 is completed but lacks labor cost; its financial values are excluded until supplied. Invoice I201 belongs to J102, has $400 outstanding, and is 12 days overdue on October 2, 2026. This association does not establish causation.

There is no approved overall margin target. The 30% threshold applies only to individual job investigation. Overhead is outside the definition. Profitability is a fixed snapshot; the date changes invoice overdue status only.

## Architecture

```mermaid
flowchart TD
    UI[Browser review] --> E[Verified evidence]
    UI --> A[Local agent]
    A --> M[Ollama model]
    M --> V[Validate arguments]
    V --> T[Approved SQL tools]
    T --> D[(SQLite)]
    T --> M
    E --> T
    A --> C[Required tool coverage]
    C --> R[Answer and trace]
```

The model requests named tools, never arbitrary SQL. Python validates fields, branches, and dates. Money is integer cents; unknown values remain NULL. Bounded recovery handles missed calls and invalid arguments. Selected demo workflows require all relevant tools to succeed before a final answer.

## Files

`src/tools.py` calculates financial results. `src/agent_local.py` implements tool selection, validation, recovery, and coverage. `src/demo_server.py` and `ui/index.html` provide the demo. Loaders rebuild the database from `data/` CSVs. `tests/` checks financial behavior and orchestration. `docs/` contains publishing instructions, validation, and a client walkthrough. Original `briefs/` and `knowledge/` preserve the learning engagement. Earlier Gemini exercises in `archive/` are reference only and are not required or imported by the local demo.

## Validation and limits

Fourteen automated tests passed during packaging. Agent tests use scripted model responses, not live inference. HTTP checks passed for HTML delivery and evidence. The new UI still needs browser and live-model acceptance on your Windows computer; see `docs/VALIDATION.md`.

AI prose can still misstate evidence. Required-tool coverage checks names and success, not every requested scope, date, or generated claim. There is no role authorization, tenant isolation, policy retrieval, historical profitability, approval workflow, or external action execution. This loopback server is for local presentation, not public hosting.

## Sharing

See `docs/GITHUB.md` and `docs/CLIENT_WALKTHROUGH.md`. Keep secrets, `.venv`, model downloads, and generated databases out of Git. A private repository is only available to authorized viewers. For prospects, present locally or share a recorded demonstration; GitHub source does not run Ollama.
