# Client demonstration walkthrough

This fictional HVAC example shows how Hicks Analytics can connect operational data to an assistant that identifies exceptions and presents evidence. It makes no claims of measured client ROI.

## Two minute demonstration

1. Open the local interface with All branches and invoice date October 2, 2026. Explain $8,500 revenue, $3,500 gross profit, and 41.18% margin, covering completed jobs with known costs.
2. Show J102 at 25% margin. The 30% rule triggers investigation, not a diagnosis. Show completed J105's missing labor cost and exclusion.
3. Show I201: $400 outstanding, 12 days past due, associated with J102. Neither the reason for nonpayment nor the cause of low margin is established.
4. Run the optional management AI review. The model selects tools; Python and SQL calculate numbers. On slow hardware, start before the meeting or show evidence first. Never present deterministic panels as live AI output.
5. Open the trace and compare the model answer with source evidence. Discuss data readiness, metric ownership, and approval needs for a real engagement.

## Client questions

Which weekly decisions take the most reporting effort? Where are labor costs, revenue, and balances stored? Who owns the metrics? Which actions require approval? What evidence would finance need to trust an answer?

## Recording

Record the browser with notifications hidden. Label the data fictional. Show real results and traces; label any edit shortening model wait time. Do not show credentials or imply unattended production readiness.
